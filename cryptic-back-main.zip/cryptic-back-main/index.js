const express = require("express");
const app = express();
const port = process.env.PORT || 3001;
const path = require("path");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const morgan = require("morgan");
const cors = require("cors");
require("dotenv").config();
app.use(cors());
app.use(morgan("dev"));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const {
  addTeam,
  getAdmin,
  getQt,
  addUser,
  deleteQuestion,
  updateLevel,
  setIsPass,
  getTeams,
  getUsers,
  getTeamUsers,
  updateUserPoints,
  addQuestion,
  editQuestions,
  getQuestion,
  checkAnswer,
  editUser,
  editTeam,
  getUser,
  deleteUser,
} = require("./lib");

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI);
const db = mongoose.connection;
db.on("error", console.error.bind(console, "connection error:"));
db.once("open", function () {
  console.log("Connected to MongoDB");
  app.post("/", (req, res) => {
    const { action } = req.body;
    console.log(action);
    switch (action) {
      case "addTeam":
        addTeam(req, res);
        break;
      case "addUser":
        addUser(req, res);
        break;
      case "getTeams":
        getTeams(req, res);
        break;
      case "getUsers":
        getUsers(req, res);
        break;
      case "updateUserPoints":
        updateUserPoints(req, res);
        break;
      case "getTeamUsers":
        getTeamUsers(req, res);
        break;
      case "getAdmin":
        getAdmin(req, res);
        break;
      case "addQuestion": 
        addQuestion(req, res);
        break;
      case "getQuestion":
        getQuestion(req, res);
        break;
      case "getUser":
        getUser(req, res);
        break;
      case "checkAnswer":
        checkAnswer(req, res);
      case "setIsPass":
        setIsPass(req, res);
        break;
      case "deleteQuestion":
        deleteQuestion(req, res);
        break;
      case "editQuestions":
        editQuestions(req, res);
        break;
      case "editUser":
        editUser(req, res);
        break;
      case "editTeam":
        editTeam(req, res);
        break;
      case "deleteUser":
        deleteUser(req, res);
        break;
      case "getQt":
        getQt(req, res);
        break;
      case "updateLevel":
        updateLevel(req, res);
        break;
      default:
        return res.status(200).json({ message: "Invalid action", status: 400 });
    }
  });

  app.listen(port, () => {
    console.log(`Server is running on port: ${port}`);
  });
});
