# function payloads

request types :
addTeam,
addUser,
getTeams,
getUsers,
getTeamUsers,
updateUserPoints

## request body

### addTeam

```json
{
  "name": "team1"
}
```

### addUser

```json
{
  "name": "user1",
  "email": "Useremail@xyz.com",
  "teamId": "team1"
}
```

### getTeams

```json
{}
```

### getUsers

```json
{}
```

### getTeamUsers

```json
{
  "teamId": "team1"
}
```

### updateUserPoints

```json
{
  "id": "user1",
  "points": 10
}
```
